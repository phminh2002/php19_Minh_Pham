<?php
    define('DIR_FILES', 'files/');
?>